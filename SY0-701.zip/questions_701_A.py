questions_701_A = [
    {
    "question": "A technician is tasked with installing additional RAM in a desktop computer. Which of the following types of RAM is MOST likely to be used?",
    "options": [
        "SODIMM",
        "DDR3",
        "ECC",
        "VRAM"
    ],
    "correct_answer": 2,
    "description": "To install additional RAM in a desktop:\n\n- SODIMM is typically used in laptops and smaller devices rather than desktops.\n- DDR3, the correct answer, is a common type of RAM used in desktop computers.\n- ECC RAM is error-correcting memory, often used in servers rather than standard desktops.\n- VRAM is used for graphics processing and is not typically installed as system RAM."
},
{
    "question": "Vertical streaks are appearing on the output of a laser printer. Which of the following items is the MOST likely cause?",
    "options": [
        "Roller",
        "Drum",
        "Transfer belt",
        "Ribbon"
    ],
    "correct_answer": 2,
    "description": "To resolve vertical streaks in a laser printer:\n\n- The roller could cause print quality issues but typically not vertical streaks.\n- The drum, the correct answer, is a key component in laser printers that can cause vertical streaks when malfunctioning.\n- The transfer belt may cause other print quality issues, but vertical streaks are often associated with the drum.\n- A ribbon is typically found in dot matrix printers, not laser printers."
},
{
    "question": "A user is trying to play a DVD on a projector. The user can hear the audio; however, the projector is showing an error message that states: HDMI Blocked due to Copy Protection. Which of the following is the MOST likely cause of the error?",
    "options": [
        "The HDMI cannot carry the signal from the DVD to the projector.",
        "The user needs to switch from HDMI to a cable standard such as DisplayPort.",
        "The projector does not support the necessary HDCP protocol.",
        "The user needs to enable copy-protected sources in the projector's settings."
    ],
    "correct_answer": 4,
    "description": "To troubleshoot the HDMI copy protection issue:\n\n- HDMI can carry the signal, but copy protection (HDCP) is likely blocking it.\n- Switching to DisplayPort will not solve the issue, as it also requires HDCP for copy-protected content.\n- The projector's lack of HDCP support could be the issue, but enabling copy-protected sources in the settings, the correct answer, resolves it."
},
{
    "question": "While implementing a non-carrier-grade wireless backhaul, a technician notices the current channel selection is extremely polluted with various RF signals. Upon performing a spectral analysis, the technician discovers a channel containing almost no RF pollution. Unfortunately, the technician is unable to select that channel. Which of the following is the MOST likely reason for this issue?",
    "options": [
        "The channel is reserved for licensed band use.",
        "The channel selection is defective; contact the manufacturer.",
        "The channel must be unlocked by the vendor.",
        "The device requires a firmware update to unlock the channel."
    ],
    "correct_answer": 3,
    "description": "To understand why the technician cannot select the clean channel:\n\n- The channel could be reserved for licensed use, but this isn't always the case.\n- A defective channel selection is unlikely without further evidence.\n- The channel must be unlocked by the vendor, the correct answer, which is often required for certain frequencies.\n- A firmware update may be required for functionality, but channel locking by the vendor is more common."
},
{
    "question": "A user submitted a support ticket that states all of the printouts from a laser printer appear to have double images imposed on them. A review of past printer support tickets shows that a maintenance kit has not been installed in more than a year. Which of the following printer consumables is MOST likely causing the issue?",
    "options": [
        "Separation pad",
        "Transfer roller",
        "Ink cartridge",
        "Fuser"
    ],
    "correct_answer": 2,
    "description": "To resolve the double images issue on a laser printer:\n\n- The separation pad is unlikely to cause this issue.\n- The transfer roller, the correct answer, can cause double images if it's worn or dirty.\n- An ink cartridge is not used in laser printers and wouldn't cause double images.\n- The fuser can cause similar issues but is less likely than the transfer roller in this scenario."
},
{
    "question": "A technician is configuring a workstation to be used as a VM host. After installing the necessary software, the technician is unable to create any VMs. Which of the following actions should be performed?",
    "options": [
        "Disable the BIOS password.",
        "Enable TPM.",
        "Enable multithreading.",
        "Enable Fast Startup."
    ],
    "correct_answer": 3,
    "description": "To create VMs on a workstation:\n\n- Disabling the BIOS password does not impact VM creation.\n- Enabling TPM is unrelated to VM creation and more related to security.\n- Enabling multithreading, the correct answer, improves CPU performance and is required for efficient VM creation.\n- Fast Startup affects boot time but does not impact VM creation."
},
{
    "question": "A user's computer is not receiving a network connection. The technician confirms that the connection seems to be down and looks for the user's port on the patch panel. The port and patch panel are not labeled. Which of the following network tools should the technician use to identify the port?",
    "options": [
        "Network tap",
        "Punchdown tool",
        "Toner probe",
        "Crimper"
    ],
    "correct_answer": 3,
    "description": "To identify the correct port on the patch panel:\n\n- A network tap is used for monitoring network traffic, not for identifying ports.\n- A punchdown tool is used to terminate cables but won't help locate the correct port.\n- A toner probe, the correct answer, allows the technician to trace the cable and find the correct port.\n- A crimper is used to attach connectors to cables but doesn't help identify ports."
}


]

